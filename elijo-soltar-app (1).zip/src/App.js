import React from 'react';

function App() {
  return (
    <div>
      <h1>Elijo Soltar, Elijo Volver a Mí</h1>
      <p>21 días para dejar ir con amor y ponerme en primer lugar.</p>
    </div>
  );
}

export default App;